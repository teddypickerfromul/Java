
public class Main {
	/**Точка входа в программу*/
	public static void main(String[] args){
		/*вывод в консоль*/
		System.out.println("Hello World");
		
	}
}
