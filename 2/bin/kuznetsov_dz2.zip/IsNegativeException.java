public class IsNegativeException extends Exception {

	private static final long serialVersionUID = 7446233588434020167L;

	public IsNegativeException() {}
	
	public IsNegativeException(String message) {
		super(message);
	}
}
