package sample5;

/*использование логических блоков при объявлении класса*/
public class DemoLogic {
	public static void main(String[] args) {

		Department obj = new Department(71);

		System.out.println("значение id=" + obj.getId());

		}
}
