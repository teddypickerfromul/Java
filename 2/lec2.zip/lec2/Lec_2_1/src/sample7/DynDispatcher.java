package sample7;

public class DynDispatcher {
	public void infoCourse(Course c) {

		System.out.println(c.toString());

		//System.out.println(c);//идентично

		}
}
