package sample2;

public class Main {
public static void main(String[] args)  {
	new Quest();
	new Quest(2012, " - это текущий год");	
}
}
