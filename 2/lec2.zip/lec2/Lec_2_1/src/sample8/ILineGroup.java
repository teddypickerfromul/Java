package sample8;

public interface ILineGroup {
	// по умолчанию public abstract

	double getPerimeter();// объявление метода
}
