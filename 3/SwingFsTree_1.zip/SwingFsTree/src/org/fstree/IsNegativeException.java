package org.fstree;

public class IsNegativeException extends Exception {

	private static final long serialVersionUID = 2746227754624307362L;
	
	public IsNegativeException() {}
	
	public IsNegativeException(String message) {
		super(message);
	}
}
